export default {
  strings: {
    generatingThumbnails: 'Generating thumbnails...',
  },
}
