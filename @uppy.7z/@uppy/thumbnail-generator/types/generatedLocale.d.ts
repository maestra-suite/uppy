/* eslint-disable */
import type { Locale } from '@uppy/core'

type ThumbnailGeneratorLocale = Locale<
    | 'generatingThumbnails'
>

export default ThumbnailGeneratorLocale