module.exports = {
  strings: {}
};