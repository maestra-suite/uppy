/* eslint-disable */
import type { Locale } from '@uppy/core'

type DragDropLocale = Locale<
    | 'dropHereOr'
| 'browse'
>

export default DragDropLocale