export default {
  strings: {
    pluginNameFacebook: 'Facebook',
  },
}
