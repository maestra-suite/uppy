/* eslint-disable */
import type { Locale } from '@uppy/core'

type FacebookLocale = Locale<
    | 'pluginNameFacebook'
>

export default FacebookLocale