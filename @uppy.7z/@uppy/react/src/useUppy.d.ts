import type Uppy from '@uppy/core'

declare function useUppy(factory: () => Uppy): Uppy

export default useUppy
