export { default } from './Instagram.jsx'
