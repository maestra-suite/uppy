export default {
  strings: {
    pluginNameInstagram: 'Instagram',
  },
}
