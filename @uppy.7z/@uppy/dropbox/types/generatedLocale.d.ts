/* eslint-disable */
import type { Locale } from '@uppy/core'

type DropboxLocale = Locale<
    | 'pluginNameDropbox'
>

export default DropboxLocale