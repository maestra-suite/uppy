export default {
  strings: {
    pluginNameDropbox: 'Dropbox',
  },
}
