export default {
  strings: {
    pluginNameZoom: 'Zoom',
  },
}
