/* eslint-disable */
import type { Locale } from '@uppy/core'

type ZoomLocale = Locale<
    | 'pluginNameZoom'
>

export default ZoomLocale