export default {
  strings: {
    // The same key is used for the same purpose by @uppy/robodog's `form()` API, but our
    // locale pack scripts can't access it in Robodog. If it is updated here, it should
    // also be updated there!
    chooseFiles: 'Choose files',
  },
}
