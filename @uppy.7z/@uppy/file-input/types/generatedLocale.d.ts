/* eslint-disable */
import type { Locale } from '@uppy/core'

type FileInputLocale = Locale<
    | 'chooseFiles'
>

export default FileInputLocale