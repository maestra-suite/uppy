# @uppy/companion-client

## 2.2.0

Released: 2022-05-30
Included in: Uppy v2.11.0

- @uppy/companion-client: Revert "Revert "@uppy/companion-client: refactor to ESM"" (Antoine du Hamel / #3730)

## 2.1.0

Released: 2022-05-14
Included in: Uppy v2.10.0

- @uppy/companion-client: refactor to ESM (Antoine du Hamel / #3693)

## 2.0.6

Released: 2022-04-07
Included in: Uppy v2.9.2

- @uppy/aws-s3,@uppy/companion-client,@uppy/transloadit,@uppy/utils: Propagate `isNetworkError` through error wrappers (Renée Kooi / #3620)

## 2.0.5

Released: 2022-02-14
Included in: Uppy v2.5.0

- @uppy/companion-client,@uppy/companion,@uppy/provider-views,@uppy/robodog: Finishing touches on Companion dynamic Oauth (Renée Kooi / #2802)
