/**
 * @param {Array} array
 * @param {Function} predicate
 * @returns {number}
 */
export default Function.prototype.call.bind(Array.prototype.findIndex)
