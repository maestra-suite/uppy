/**
 * Converts list into array
 */
export default Array.from
