export { default } from './Informer.jsx'
