export default {
  strings: {
    pluginNameGoogleDrive: 'Google Drive',
  },
}
