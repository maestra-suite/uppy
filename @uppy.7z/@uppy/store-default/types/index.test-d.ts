import DefaultStore from '..'

const store = DefaultStore()

store.setState({ a: 'b' })
store.getState()
