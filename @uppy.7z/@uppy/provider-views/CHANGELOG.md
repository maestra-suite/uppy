# @uppy/provider-views

## 2.1.2

Released: 2022-07-06
Included in: Uppy v2.12.2

- @uppy/provider-views: improve logging (Mikael Finstad / #3638)

## 2.1.1

Released: 2022-05-30
Included in: Uppy v2.11.0

- @uppy/provider-views: Add onKeyPress event handler to capture e.shiftKey, unavailable in onChange (Artur Paikin / #3768)

## 2.1.0

Released: 2022-05-14
Included in: Uppy v2.10.0

- @uppy/provider-views: refactor to ESM (Antoine du Hamel / #3715)

## 2.0.8

Released: 2022-03-16
Included in: Uppy v2.8.0

- @uppy/provider-views: provider-view: fix breadcrumbs (Artur Paikin / #3535)

## 2.0.7

Released: 2022-02-14
Included in: Uppy v2.5.0

- @uppy/companion-client,@uppy/companion,@uppy/provider-views,@uppy/robodog: Finishing touches on Companion dynamic Oauth (Renée Kooi / #2802)
- @uppy/provider-views: Unsplash: UI improvements (Artur Paikin / #3438)
