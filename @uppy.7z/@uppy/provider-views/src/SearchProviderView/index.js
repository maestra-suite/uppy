export { default } from './SearchProviderView.jsx'
